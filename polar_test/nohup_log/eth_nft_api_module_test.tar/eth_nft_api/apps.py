from django.apps import AppConfig


class EthNftApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eth_nft_api'
