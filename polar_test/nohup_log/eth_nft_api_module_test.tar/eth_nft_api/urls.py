#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : urls.py
# @Time    : 2023/8/15 15:21
# @motto   :  rain cats and dogs

from django.urls import re_path
import functools
import time
from rest_framework.urlpatterns import format_suffix_patterns
from eth_nft_api.views.project.transfer.week_transfer_record_count_rank import WeekTransferCountRankView
from eth_nft_api.views.project.transfer.year_transfer_record_count_rank import YearTransferCountRankView
from eth_nft_api.views.project.transfer.month_transfer_record_count_rank import MonthTransferCountRankView
from eth_nft_api.views.project.transfer.day_transfer_record_detail import DayTransferdetailView
from eth_nft_api.views.project.transfer.year_transfer_record_count import YearTransferCountView
from eth_nft_api.views.project.week_report_json_view import Week_report_json
from eth_nft_api.views.project.transfer.transfer_contract_every_day_count import TransferContractEveryDayCountView
from eth_nft_api.views.project.transfer.transfer_contract_every_week_count import  TransferContractEveryWeekCountView
from eth_nft_api.views.project.transfer.transfer_contract_every_month_count import  TransferContractMonthCountView
from eth_nft_api.views.project.transfer.transfer_contract_several_month_count import  TransferContractSeveralMonthCountView
from eth_nft_api.views.project.trade.week_trade_rank import  WeekTradeRankView
from eth_nft_api.views.project.trade.every_contract_trade_detail import  EveryContractTradeDetailView

urlpatterns = [
    # -------------- transfer ----------------
    re_path(r'^week-transfer-record-rank$', WeekTransferCountRankView.as_view()),
    re_path(r'^year-transfer-record-rank$', YearTransferCountRankView.as_view()),
    re_path(r'^month-transfer-record-rank$', MonthTransferCountRankView.as_view()),
    re_path(r'^transfer-contract-day-detail$', DayTransferdetailView.as_view()),
    re_path(r'^transfer-contract-year-count$', YearTransferCountView.as_view()), # 每年的总数
    re_path(r'^week-report$', Week_report_json.as_view()),
    re_path(r'^transfer-contract-every-day-count$', TransferContractEveryDayCountView.as_view()), # contract每天的总数
    re_path(r'^transfer-contract-every-week-count$', TransferContractEveryWeekCountView.as_view()), # contract每周的总数
    re_path(r'^transfer-contract-every-month-count$', TransferContractMonthCountView.as_view()), # contract每月的总数
    re_path(r'^transfer-contract-several-month-count$', TransferContractSeveralMonthCountView.as_view()), # contract每月的总数
    # -------------- trade ----------------
    re_path(r'^week-trade-volume-rank$', WeekTradeRankView.as_view()),
    re_path(r'^every-contract-trade-detail$', EveryContractTradeDetailView.as_view()),


]

urlpatterns = format_suffix_patterns(urlpatterns)