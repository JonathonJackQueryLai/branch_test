#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : every_contract_trade_detail.py
# @Time    : 2023/8/31 15:01
# @motto   :  rain cats and dogs
# !/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : week_trade_rank.py
# @Time    : 2023/8/28 10:30
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures import as_completed
import datetime
import threading
from eth_nft_api_module_test.util.running_time import calculate_execution_time
import functools
import time
from collections import OrderedDict


# SELECT sum(price_value)
# FROM contract_info
# WHERE block_number BETWEEN 18007050 AND 18007295 group by contract_address ;


class EveryContractTradeDetailView(APIView):

    def exec_sql(self, sql, uri):
        df = pl.read_database(query=sql, connection=uri)
        return df

    @calculate_execution_time
    def get(self, request):
        # todo: 先查表后计算
        data = request.data
        if ["project_list"].__len__() == 0:
            return Response({'data': None, "message": "project_list is None"},
                            status=status.HTTP_400_BAD_REQUEST)
        # contract_name = data['contract_name']
        contract_address = data['contract_address']
        start_date = data['start_date']
        end_date = data['end_date']
        #
        min_weekly = pl.read_database(
            f"select min_block_num from day_block_number_min_max where date = '{start_date}' ",
            connection=DbUri.ETH_NFT_API_URI)['min_block_num'][0]
        max_weekly = pl.read_database(f"select max_block_num from day_block_number_min_max where date = '{end_date}' ",
                                      connection=DbUri.ETH_NFT_API_URI)['max_block_num'][0]
        if start_date > end_date:
            return Response({'data': None, 'message': f'param data is wrong'}, status=status.HTTP_400_BAD_REQUEST)
        sql_li = [
            f"select date_of_rate as date ,eth_usd_rate  from rate_info where date_of_rate >= '{start_date}' and date_of_rate <= '{end_date}' ",
            f"select contract_address,contract_name from contract_info ",
            f"select block_number,date_of_block as date from block_info where block_number >=  {min_weekly} and  block_number <=  {max_weekly}",
            f"select block_number,contract_address,price_value as volume_eth from trade_record where  block_number >= {min_weekly} and block_number <= {max_weekly} and (currency_address = '0x0000000000000000000000000000000000000000' or currency_address = '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2') and contract_address = '{contract_address}'",
        ]
        # block_number_list = pl.read_database(
        #     f"select * from day_block_number_min_max where date >= '{start_date}' and date <= '{end_date}'",
        #     connection=DbUri.ETH_NFT_API_URI)
        # block_number_list = block_number_list.with_columns(
        #     block_number_list['date'].str.to_date("%Y-%m-%d").alias("date"))
        # start_date =datetime.datetime.strptime(start_date,'%Y-%m-%d')
        # end_date =datetime.datetime.strptime(end_date,'%Y-%m-%d')
        # date_range = pl.date_range(start_date,end_date,eager=True).to_list()
        # date_range = [i.strftime('%Y-%m-%d') for i in date_range]
        # "select sum(price_value) from trade_record where block_number >= 15180450 and block_number<=15378521 "
        try:
            # 创建线程池
            with concurrent.futures.ThreadPoolExecutor() as executor:
                # 提交任务到线程池
                futures = [executor.submit(self.exec_sql, sql, DbUri.ETH_NFT_URI) for sql in sql_li]

                results = OrderedDict()

                # 获取任务结果并按顺序存储到有序字典中
                for sql, future in zip(['rate_info',
                                        'contract_info',
                                        'block_info',
                                        'trade_info',
                                        ], futures):
                    result = future.result()
                    results[sql] = result
        except Exception as ex:
            print(ex)
            return Response({'data': None, 'message': f'{ex}', 'code': status.HTTP_500_INTERNAL_SERVER_ERROR},
                            status=status.HTTP_404_NOT_FOUND)
        rate_info = results['rate_info']
        contract_info = results['contract_info']
        block_info = results['block_info']
        trade_info = results['trade_info']
        trade_info = trade_info.join(block_info, on="block_number", how="left")
        trade_info = trade_info.join(rate_info, on="date", how="left")
        trade_info = trade_info.with_columns(pl.col('eth_usd_rate'))
        trade_info = trade_info.with_columns(
            (trade_info["volume_eth"] * trade_info["eth_usd_rate"]).rename('volume_usd'))
        trade_info = trade_info.with_columns(trade_info['volume_eth'].rename('price_value_sum'),
                                             trade_info['volume_usd'].rename('volume_usd_sum'), ) \
            .groupby('date').agg([pl.sum('volume_eth'), pl.sum('volume_usd')])
        return Response({'data': trade_info.to_dicts(), "message": "successfully", "code": status.HTTP_200_OK},
                        status=status.HTTP_200_OK)
