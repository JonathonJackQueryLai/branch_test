#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : week_trade_rank.py
# @Time    : 2023/8/28 10:30
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures import as_completed
import datetime
import threading
from eth_nft_api_module_test.util.running_time import calculate_execution_time
import functools
import time
from collections import OrderedDict


# SELECT sum(price_value)
# FROM contract_info
# WHERE block_number BETWEEN 18007050 AND 18007295 group by contract_address ;


class WeekTradeRankView(APIView):

    def exec_sql(self, sql, uri):
        df = pl.read_database(query=sql, connection=uri)
        return df

    @calculate_execution_time
    def get(self, request):
        # todo: 先查表后计算
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        last_weekly_et = (datetime.datetime.strptime(start_date, '%Y-%m-%d') - datetime.timedelta(days=1)).strftime(
            '%Y-%m-%d')
        last_weekly_st = (datetime.datetime.strptime(start_date, '%Y-%m-%d') - datetime.timedelta(days=7)).strftime(
            '%Y-%m-%d')
        if start_date > end_date:
            return Response({'data': None, 'message': f'param data is wrong'}, status=status.HTTP_400_BAD_REQUEST)
        min_weekly = pl.read_database(
            f"select min_block_num from day_block_number_min_max where date = '{start_date}' ",
            connection=DbUri.ETH_NFT_API_URI)['min_block_num'][0]
        max_weekly = pl.read_database(f"select max_block_num from day_block_number_min_max where date = '{end_date}' ",
                                      connection=DbUri.ETH_NFT_API_URI)['max_block_num'][0]

        last_min_weekly = pl.read_database(
            f"select min_block_num from day_block_number_min_max where date = '{last_weekly_st}' ",
            connection=DbUri.ETH_NFT_API_URI)['min_block_num'][0]
        last_max_weekly = \
            pl.read_database(f"select max_block_num from day_block_number_min_max where date = '{last_weekly_et}' ",
                             connection=DbUri.ETH_NFT_API_URI)['max_block_num'][0]
        sql_li = [
            f"select date_of_rate as date ,eth_usd_rate  from rate_info where date_of_rate >= '{start_date}' and date_of_rate <= '{end_date}' ",
            f"select contract_address,contract_name from contract_info ",
            f"select block_number,date_of_block as date from block_info where block_number >=  {min_weekly} and  block_number <=  {max_weekly}",
            f"select block_number,contract_address,price_value as volume_eth from trade_record where  block_number >= {min_weekly} and block_number <= {max_weekly} and (currency_address = '0x0000000000000000000000000000000000000000' or currency_address = '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2')",
            f"select block_number,contract_address,price_value as volume_eth from trade_record where  block_number >= {last_weekly_st} and block_number <= {last_weekly_et} and (currency_address ='0x0000000000000000000000000000000000000000' or currency_address = '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2')"
        ]
        try:
            # 创建线程池
            with concurrent.futures.ThreadPoolExecutor() as executor:
                # 提交任务到线程池
                futures = [executor.submit(self.exec_sql, sql, DbUri.ETH_NFT_URI) for sql in sql_li]

                results = OrderedDict()

                # 获取任务结果并按顺序存储到有序字典中
                for sql, future in zip(['rate_info',
                                        'contract_info',
                                        'block_info',
                                        'trade_info',
                                        'last_week_trade_info'], futures):
                    result = future.result()
                    results[sql] = result
        except Exception as ex:
            print(ex)
            return Response({'data': None, 'message': f'{ex}', 'code': status.HTTP_500_INTERNAL_SERVER_ERROR},
                            status=status.HTTP_404_NOT_FOUND)
        rate_info = results['rate_info']
        contract_info = results['contract_info']
        block_info = results['block_info']
        trade_info = results['trade_info']
        last_week_trade_info = results['last_week_trade_info']

        #  block_number >= 17959394 and block_number <= 18007049        trade_info = trade_info.join(contract_info, on="contract_address", how="left")

        trade_info = trade_info.join(block_info, on="block_number", how="left")
        trade_info = trade_info.join(rate_info, on="date", how="left")
        trade_info = trade_info.with_columns(pl.col('eth_usd_rate'))
        trade_info = trade_info.with_columns(
            (trade_info["volume_eth"] * trade_info["eth_usd_rate"]).rename('volume_usd'))
        trade_info = trade_info.with_columns(trade_info['volume_eth'].rename('price_value_sum'),
                                             trade_info['volume_usd'].rename('volume_usd_sum'),)\
            .groupby('contract_address').agg([pl.sum('volume_eth'), pl.sum('volume_usd')]).sort('volume_eth',descending=True).head(10)

        trade_info = trade_info.join(contract_info, on="contract_address", how="left")
        rank_df = pl.DataFrame({'rank': [i for i in range(1, trade_info.__len__() + 1)]})
        trade_info = trade_info.hstack(rank_df)
        return Response({'data': trade_info.to_dicts(), "message": "successfully", "code": status.HTTP_200_OK},
                        status=status.HTTP_200_OK)


