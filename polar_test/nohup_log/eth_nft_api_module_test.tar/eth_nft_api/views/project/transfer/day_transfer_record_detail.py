#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : day_transfer_record_detail.py
# @Time    : 2023/8/16 8:55
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures  import as_completed
import datetime


def parallel_process(processing_func, post_process_func, args: list, engine, return_data=False):
    processed_list = []
    with ProcessPoolExecuton(maxworkers=4)as executor:
        res_gen = [executor.submit(processing_func, *arg) if isinstance(arg, tuple) else executor.submit(processing_func,arg) for arg in args]
        with ThreadPoolExecutor()  as  thread_executor:
            for future in as_completed(res_gen):
                processed_list.append(future.result())
            thread_executor.map(post_process_func,itertools.cycle([engine]),processed_list)
    if return_data:
        return processed_ist

class DayTransferdetailView(APIView):
    # 部分更新
    def get(self, request):
        data = request.data
        if ["project_list"].__len__() == 0:
            return Response({'data': None, "message": "project_list is None"},
                        status=status.HTTP_400_BAD_REQUEST)
        project_list = data['project_list']
        address_list = [i['contract_address'] for i in project_list]
        start_date = data['start_date']
        end_date = data['end_date']
        date_list = pl.date_range(datetime.datetime.strptime(start_date, "%Y-%m-%d"), datetime.datetime.strptime(end_date, "%Y-%m-%d"),eager=True)
        table_name_list = list(map(lambda x:'day_transfer_count_' + x.strftime("%Y-%m-%d").replace('-', '_'),date_list))
        date_list = list(map(lambda x: x.strftime("%Y-%m-%d"),date_list))
        def read_table(table):
            try:
                sql = f"SELECT * FROM {table} WHERE contract_address in {tuple(address_list)}"
                df = pl.read_database(sql, DbUri.ETH_NFT_API_URI)
            except Exception as ex:
                return "not data today"
            return df

        # 创建线程池
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # 提交任务到线程池
            futures = [executor.submit(read_table,table) for table in table_name_list]
            # 获取任务结果
            results = {day.replace('_', '-'): future.result().to_dicts() if not isinstance(future.result(),str) else future.result() for day, future in zip(date_list, concurrent.futures.as_completed(futures))}
        # 返回响应
        return Response({'data': results, "message": "successfully","code":status.HTTP_200_OK},
                        status=status.HTTP_200_OK)

