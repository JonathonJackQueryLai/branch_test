#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : month_transfer_record_count_rank.py
# @Time    : 2023/8/23 16:46
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import datetime
import concurrent.futures
from concurrent.futures import as_completed


class MonthTransferCountRankView(APIView):

    def get_month_dates(self, start_date, end_date):
        start_date = start_date if start_date.count('-') == 1 else '-'.join(start_date.split('-')[:2])
        end_date = end_date if end_date.count('-') == 1 else '-'.join(end_date.split('-')[:2])
        # 将开始日期和结束日期转换为datetime对象
        start_date = datetime.datetime.strptime(start_date, "%Y-%m")
        end_date = datetime.datetime.strptime(end_date, "%Y-%m")

        # 初始化结果列表
        month_dates = []

        # 循环生成每个月的日期
        current_date = start_date
        while current_date <= end_date:
            month_dates.append(current_date.strftime("%Y-%m"))
            current_date += datetime.timedelta(days=31)

        return month_dates

    def read_table(self, month):
        df = pl.read_database(query=f"SELECT * FROM month_transfer_head_rank_{month}", connection_uri=DbUri.ETH_NFT_API_URI)
        return df.to_dicts()
    # 部分更新
    def get(self, request):
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        if start_date > end_date:
            return Response({'data': None, 'message': f'param data is wrong'}, status=status.HTTP_400_BAD_REQUEST)
        month_li = self.get_month_dates(start_date, end_date)
        month_li = [i.replace('-', '_') for i in month_li]
        try:
            # 创建线程池
            with concurrent.futures.ThreadPoolExecutor() as executor:
                # 提交任务到线程池
                futures = [executor.submit(self.read_table, month) for month in month_li]
                # 获取任务结果
                # results = {month.replace('_', '-'): future.result() if not future.result().is_empty() and not isinstance(future.result(),
                #                                                                                  str) else future.result()
                #            for month, future in zip(month_li, concurrent.futures.as_completed(futures))}
                results = {month.replace('_', '-'): future.result() for month, future in zip(month_li, concurrent.futures.as_completed(futures))}

                # 返回响应
                return Response({'data': results, "message": "successfully"},
                                status=status.HTTP_200_OK)
        except Exception as ex:
            print(ex)
            return Response({'data': None, 'message': f'{ex}','code':status.HTTP_404_NOT_FOUND}, status=status.HTTP_404_NOT_FOUND)



