#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : transfer_contract_several_month_count.py
# @Time    : 2023/8/22 17:06
# @motto   :  rain cats and dogs
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : transfer_contract_every_month_count.py
# @Time    : 2023/8/22 16:17
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures import as_completed
import datetime
from dateutil.relativedelta import relativedelta



class TransferContractSeveralMonthCountView(APIView):
    # 部分更新
    def get(self, request):
        month = request.GET.get('month')
        # 什么都没有
        if not month :
            end_date = datetime.datetime.now().date()
            start_date = end_date + relativedelta(months=-1)
            end_date = end_date.strftime("%Y-%m-%d")
            start_date = start_date.strftime("%Y-%m-%d")
            query = f"SELECT sum(changed_hands) FROM transfer_contract_every_day_count WHERE day >= '{start_date}' and day <= '{end_date}'"
        else:
            month = datetime.datetime.strptime(month, "%Y-%m-%d") if isinstance(month,str) and month.count('-') == 2 else datetime.datetime.strptime(month, "%Y-%m")
            next_month = month + relativedelta(months=1)
            next_month = next_month.strftime("%Y-%m")
            next_month = datetime.datetime.strptime(next_month, "%Y-%m")
            end_date = next_month + relativedelta(days=-1)
            end_date =end_date.strftime("%Y-%m-%d")
            query = f"SELECT sum(changed_hands) FROM transfer_contract_every_day_count WHERE day >= '{month}-01' and day<= '{end_date}'"
        try:
            df = pl.read_database(query=query, connection=DbUri.WRITE_URI)
        except Exception as ex:
            return Response({'data': None, "message": f"failed:{ex}", "code": 404},
                            status=status.HTTP_200_OK)
        # 返回响应
        return Response({'data': df.to_dicts(), "message": "successfully", "code": status.HTTP_200_OK},
                        status=status.HTTP_200_OK)


