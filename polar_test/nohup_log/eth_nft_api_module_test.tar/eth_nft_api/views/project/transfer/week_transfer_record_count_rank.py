#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : week_transfer_record_count_rank.py
# @Time    : 2023/8/15 15:07
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
class WeekTransferCountRankView(APIView):

    # 部分更新
    def get(self, request):
        start_date = request.GET.get('start_date')
        start_date = start_date.replace('-','_')
        try:
            df = pl.read_database(query= f"SELECT * FROM week_transfer_df_head_rank_{start_date}",connection_uri = DbUri.ETH_NFT_API_URI)
        except Exception as ex:
            return Response({'data':None,'message':f'data is not found'},status=status.HTTP_404_NOT_FOUND)

        df = df.to_dicts()
        # 返回响应
        return Response({'data': df, "message": "successfully"},
                        status=status.HTTP_200_OK)