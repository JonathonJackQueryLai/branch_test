#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : year_transfer_record_count.py
# @Time    : 2023/8/18 16:02
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures  import as_completed
import datetime

class YearTransferCountView(APIView):
    # 部分更新
    def get(self, request):
        start_year = int(request.GET.get('start_year'))
        end_year = int(request.GET.get('end_year'))
        if start_year > end_year:
            return Response({'data': None, "message": f"start_year >end_year", "code": status.HTTP_400_BAD_REQUEST},
                            status=status.HTTP_200_OK)
        if start_year > datetime.datetime.now().year or  start_year < 2015  or end_year > datetime.datetime.now().year or  end_year < 2015:
            return Response({'data': None, "message": f"no data of year {year}", "code": status.HTTP_404_NOT_FOUND},
                            status=status.HTTP_200_OK)
        table = 'year_transfer_count'
        sql = f"SELECT * FROM {table} WHERE year >= {start_year} and year <= {end_year}"
        df = pl.read_database(sql, DbUri.ETH_NFT_API_URI)
        # 返回响应
        return Response({'data': df.to_dicts(), "message": "successfully", "code": status.HTTP_200_OK},
                        status=status.HTTP_200_OK)
