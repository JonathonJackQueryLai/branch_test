#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : year_transfer_record_count_rank.py
# @Time    : 2023/8/23 16:46
# @motto   :  rain cats and dogs
import datetime

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
class YearTransferCountRankView(APIView):

    # 部分更新
    def get(self, request):
        start_year = request.GET.get('start_year')
        end_year = request.GET.get('end_year')
        if not start_year and not end_year:
            query = f"SELECT * FROM year_transfer_head_rank_{datetime.datetime.date().year}"
        elif (start_year == None or end_year == None) or (start_year == end_year):
            year = start_year if start_year else end_year
            query = f"SELECT * FROM year_transfer_head_rank_{year}"
        elif start_year > end_year:
            return Response({'data': None, 'message': f'param data is wrong'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            res_dict = {'data':[]}
            for year in range(int(start_year),int(end_year) + 1):
                df = pl.read_database(query= f"SELECT * FROM year_transfer_head_rank_{year}",connection_uri = DbUri.ETH_NFT_API_URI)
                res_dict['data'].append({year:df.to_dicts()})
            res_dict['message'] = 'successful'
            res_dict['code'] = status.HTTP_200_OK
            return Response(res_dict,status=status.HTTP_404_NOT_FOUND)
        df = pl.read_database(query =query,
            connection_uri=DbUri.ETH_NFT_API_URI)
        df = df.to_dicts()
        # 返回响应
        return Response({'data': df, "message": "successfully"},
                        status=status.HTTP_200_OK)