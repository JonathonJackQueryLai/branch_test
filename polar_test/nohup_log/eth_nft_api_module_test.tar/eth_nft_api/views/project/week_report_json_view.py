#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : Jonathon
# @File    : week_report_json_view.py
# @Time    : 2023/8/17 13:55
# @motto   :  rain cats and dogs
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
import polars as pl
from eth_nft_api_module_test.util.db_uri import DbUri
import json
import concurrent.futures
from concurrent.futures  import as_completed
import datetime
import os
import glob
class Week_report_json(APIView):
    # 部分更新
    def get(self, request):
        monday_date = request.GET.get('monday_date')
        print(os.getcwd())
        # path = r'D:\hkupro\eth_nft_api_module_test\eth_nft_api\views\2023-08-07.json'
        path = f'/home/project/eth_nft_data_module/weekreport/eth_nft_api/week_report_module/template_json/{monday_date}.json'
        try:
            with open(path,'r') as f:
                result = f.read()
        except Exception as ex:
            return Response({'data': None, "message": "no files",'code':status.HTTP_404_NOT_FOUND})
        # 返回响应
        return Response({'data': result, "message": "successfully",'code':status.HTTP_200_OK},
                        status=status.HTTP_200_OK)