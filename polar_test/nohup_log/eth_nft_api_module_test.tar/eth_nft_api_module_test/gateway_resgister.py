import threading
import time
import grpc
import framework_pb2
import framework_pb2_grpc


# 注册服务
def register(framework_addr, service_name, addr):
    # with grpc.insecure_channel(framework_addr) as channel:
    channel = grpc.insecure_channel(framework_addr)
    print("i am register gate")
    client = framework_pb2_grpc.FrameworkV1Stub(channel)
    resp = client.ServiceRegister(framework_pb2.ServiceInfo(serviceName=service_name, addr=addr))
    if resp.code != 20000:
        print("注册失败")


# 心跳
# def heart_beat(framework_addr, service_name, addr):
#     with grpc.insecure_channel(framework_addr) as channel:
#         while True:
#             client = framework_pb2_grpc.FrameworkV1Stub(channel)
#             try:
#                 resp = client.HealthCheck(framework_pb2.HeartBeatInfo(serviceName=service_name, addr=addr))
#             except Exception as ex:
#                 print(f'resp:{ex}')
#                 print("心跳失败")
#                 register(framework_addr, service_name, addr)
#             time.sleep(5)
#             # # print("heart beat test")
#             # if resp.code != 20000:
#             #     print("心跳失败")
#             #     register(framework_addr, service_name, addr)

def heart_beat(framework_addr, service_name, addr):
    with grpc.insecure_channel(framework_addr) as channel:
        while True:
            client = framework_pb2_grpc.FrameworkV1Stub(channel)
            try:
                resp = client.HealthCheck(framework_pb2.HeartBeatInfo(serviceName=service_name, addr=addr))
                if resp.code != 20000:
                    print("心跳失败")

            except Exception as e:
                with open("./home/fengzhongjia/work/data_vendor/logs/web_gate.log", 'a') as ff:
                    ff.write(e)
                print("心跳失败", e)
                register(framework_addr, service_name, addr)

            time.sleep(5)


def gateway_register_and_heart_beat():
    register('172.20.0.1:23300', "eth-nft-api", "172.20.0.23:23376")
    # 5秒之后异步执行心跳方法
    threading.Timer(5, heart_beat, args=('172.20.0.1:23300', "eth-nft-api", "172.20.0.23:23376")).start()
